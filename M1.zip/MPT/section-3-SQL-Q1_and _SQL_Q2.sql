--Author name: Vidya Honde
--Creation date: 20-11-18


use Training;
create schema Vidya;

CREATE TABLE Vidya.CUSTOMER(
	CustomerID INT PRIMARY KEY, 
	CustomerName VARCHAR(40), 
	PhoneNumber VARCHAR(13), 
	EmailId VARCHAR(50),
	City VARCHAR(35)
)

exec sp_help [Vidya.CUSTOMER];

CREATE TABLE [Vidya.ORDER](
	OrderId INT PRIMARY KEY,
	OrderDate Date,
	ProductName VARCHAR(50),
	Price MONEY,
	Quantity INT,
	CustomerID INT
)

exec sp_help [Vidya.ORDER];


--insert into table Customer present in Vidya Schema.
INSERT INTO Vidya.CUSTOMER VALUES
(101,'Robert','9087654321','robertd@gmail.com','Mumabi'),
(102,'Saket Sharma','9908765434','saketsharma@rediff.com','Pune'),
(103,'Raksha','7890654321','raksha@gmail.com','Mumabi'),
(104,'Adarsh','8899765432','adarshs@gmail.com','Mumabi'),
(105,'Kavya','9807654321','kavya@rediff.com','Pune')

--view the date from [Vidya.CUSTOMER] table.
select * from [Vidya.CUSTOMER]

----insert into table Order present in Vidya Schema.

INSERT INTO [Vidya.ORDER] VALUES
(1001,'2016-02-22','Pen Drive', 600, 3, 101),
(1002,'2016-05-05','Memory Card', 450, 2, 102),
(1003,'2016-03-12','Memory Card', 450, 3, 101),
(1004,'2016-05-03','Speaker', 1200, 2, 103),
(1005,'2016-08-08','Memory Card', 450, 1, 105)

--view the date from [Vidya.ORDER] table.
select * from [Vidya.ORDER]

--Q2.
--1.
select CustomerName from Vidya.CUSTOMER 
WHERE CustomerID IN(
select CustomerID from  [Vidya.ORDER]
WHERE ProductName=(
SELECT ProductName from [Vidya.Order]
where CustomerId=(SELECT CustomerId from Vidya.CUSTOMER
where CustomerName='saket sharma')))

--2.
create columnstore index orderIndex on [Vidya.ORDER](OrderId, OrderDate)

--3.
select o.OrderId,c.CustomerName,o.ProductName,o.Price,o.Quantity, 
(select (O.Price *O.Quantity) from  [Vidya.ORDER] where o.orderDate  between '01-01-2016' and '31-06-2016') as TotalAmount
from  Vidya.CUSTOMER c
join [Vidya.ORDER] o  
on(c.CustomerID=o.CustomerID)
where o.OrderDate between '2016/01/01' and '2016/06/03';

--4.Procedure which update city of customer depends on its customerId

create procedure updateCustomerCity @custId int , @custCity varchar(40)
as
begin
	update Vidya.CUSTOMER set City=@custCity where CustomerID=@custId 		
end

exec updateCustomerCity 103, 'Pune' 
select * from  Vidya.CUSTOMER

--5.View
CREATE VIEW [Vidya.vw_CustomerOrder] as 
(SELECT o.OrderId, o.OrderDate, o.ProductName, o.Price, o.Quantity
FROM [Vidya.ORDER] o inner join Vidya.CUSTOMER c
on(c.CustomerID=o.CustomerID) where c.City like'M%')

select * from [Vidya.vw_CustomerOrder]

--6.
SELECT OrderId, ProductName,Price,Quantity,(Price *Quantity) as Total_Biling_Amount
FROM [Vidya.ORDER]  








