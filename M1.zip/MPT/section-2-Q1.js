/* File               : 164363_Vidya_Q2.js
 * Author Name          : Vidya Honde
 * Desc                 : program to calculate total biling amount.
 * Creation Date        : 20-11-2018
 * Version              : 1.0-->
*/
// function to calculate total bill for customer's product
function calculateTotalBill() {

    var custName = document.getElementById("txtCustName").value;
    var custPhone = document.getElementById("txtPhoneNo").value;
    var custEmailId = document.getElementById("txtCustemail").value;
    var productName = document.getElementById("txtProdName").value;
    var price = document.getElementById("txtPrice").value;
    var qty = document.getElementById("txtQty").value;
    var totalAmount;

    if((price>0) && (qty>0))
    {
        totalAmount = (price * qty);
        alert(totalAmount);
    }
    else
    {
        alert("Enter positive value for quantity and price")
    }
}