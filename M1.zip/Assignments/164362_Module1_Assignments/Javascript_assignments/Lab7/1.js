

function newWin() {
    var x = (document.product_form.qty1.value);
    var x1 = (document.product_form.qty2.value);
    var x2 = (document.product_form.qty3.value);
    var x3 = (document.product_form.qty4.value);

    var html_string="<html><head><title>bill</title></head><body><h1>INVOICE</h1><table border='1'><tr><td>Product</td><td>Quantity</td><td>Price</td><td>Total</td></tr>"

    var barbie = document.getElementById("barbie1").value;
    //alert(barbie);
    var calculator = document.getElementById("calculator1").value;
    //alert(calculator)
    var mobile = document.getElementById("mobile1").value;
    //alert(mobile)
    var dvd = document.getElementById("dvd1").value;
    // alert(dvd)

    var myWindow;
    if ((x == null || x == "") && (x1 == null || x1 == "") && (x2 == null || x2 == "") && (x3 == null || x3 == "")) {
        alert("no item selected");
    }
    else {
       
        //var table = document.getElementById('product_table');

        // for (var r = 0, n = table.rows.length; r < n; r++) {
        //     for (var c = 0, m = table.rows[r].cells.length; c < m; c++) {
        //         if (table.rows[r].cells[c].innerHTML != " " || table.rows[r].cells[c].innerHTML != null) {
        //             isTrue = true;

        //             if (isTrue) {
        //                 html_string += "<tr><td>" + table.rows[r].cells[c].innerHTML + "</td></tr>";
        //                 isTrue = false;
        //             }
        //         }
        //     }
        // }

                    if(barbie>0)
                    {
                        html_string+="<tr><td>Barbie</td><td>"+barbie+"</td><td>20</td><td>"+(barbie*20)+"</td></tr>"
                    }

                    if(calculator>0)
                    {
                        html_string+="<tr><td>Calculator</td><td>"+calculator+"</td><td>30</td><td>"+(calculator*30)+"</td></tr>"
                    }

                    if(mobile>0)
                    {
                        html_string+="<tr><td>Mobile</td><td>"+barbie+"</td><td>40</td><td>"+(mobile*40)+"</td></tr>"
                    }

                     if(dvd>0)
                    {
                       html_string+="<tr><td>LG DVD</td><td>"+dvd+"</td><td>50</td><td>"+(dvd*50)+"</td></tr>"
                    }

        html_string += "</table></body></html>";


        // var cell1 = document.getElementById("barbie").getElementsByTagName("td");
        // var cell2 = document.getElementById("calculator").getElementsByTagName("td");
        // var cell3 = document.getElementById("mob_phone").getElementsByTagName("td");
        // var cell3 = document.getElementById("lg_dvd").getElementsByTagName("td");

        // var index;
        // var str1 = "cell";
        // 

        // for (index = 1; index < 4; index++) {
        //     var s = str1.concat(index, "[", index, "]");
        //     if ((str1.concat(index, [index - 1])).value != "" || (str1.concat(index, [index - 1])).value != null) {
        //         isTrue = true;
        //         

        //             isTrue = false;
        //         }
        //     }
        // }
        myWindow = open("", "myNewWin");
        myWindow.document.write(html_string);
        myWindow.focus();
    }

}