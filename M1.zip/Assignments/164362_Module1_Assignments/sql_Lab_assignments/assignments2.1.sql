--Author name: Vidya Honde
--Creation date: 15-11-18


use Training_24oct18_pune

--1.List the empno, name and Department No of the employees who have got
--experience of more than 18 years.
select * from staff_master
select * from department_master

use Training;
select s.staff_name,s.staff_code, d.dept_code from staff_master s
inner join Department_master d on(s.Dept_Code=d.Dept_code)
where s.experience>18;

--2.Display the name and salary of the staff. Salary should be represented as X. Each X
--represents a 1000 in salary. It is assumed that a staff�s salary to be multiples of 1000
--, for example a salary of 5000 is represented as XXXXX
--Sample Output
--JOHN 10000 XXXXXXXXXX
--ALLEN 12000 XXXXXXXXXXXX

select staff_name,replicate('X',(staff_sal/1000)) as Salary from staff_master;


--3.List out all the book code and library member codes whose return is still pending
select bt.book_code, st.staff_code,bt.book_actual_return_date from book_transaction bt full join staff_master st
on(bt.staff_code=st.staff_code) where bt.book_actual_return_date is null;

select * from book_master
select * from staff_master
select * from book_transaction

--4.List all the staff�s whose birthday falls on the current month
select * from staff_master where datename(month,staff_dob)=datename(month,getdate())

--5.How many books are stocked in the library?
select * from book_transaction bt inner join book_master bm 
on(bt.book_code=bm.book_code) where bt.book_actual_return_date is not null

--6.How many books are there for topics Physics and Chemistry?
select * from book_master 
where book_category='Physics' or book_category='Chemistry'

--7.How many members are expected to return their books today?
select * from book_transaction bt inner join staff_master sm 
on(bt.staff_code=sm.staff_code)
where bt.book_expected_return_date=getdate()

--8.Display the Highest, Lowest, Total & Average salary of all staff. Label the columns
--Maximum, Minimum, Total and Average respectively. Round the result to nearest
--whole number
select ceiling(max(staff_sal)) as Maximum,ceiling(min(staff_sal)) as Minimum,
ceiling(sum(staff_sal)) as Total, ceiling(avg(staff_sal)) as Average  from staff_master


--9.How many staffs are managers�?

select * from staff_master where mgr_code is not null and mgr_name is not null 

--10.List out year wise total students passed. The report should be as given below. A
--student is considered to be passed only when he scores 60 and above in all 3
--subjects individually
--Year No of students passed
 select student_code,student_year,count(*) from Student_marks where
 (subject1>=60 and subject2>=60 and subject3>=60) group by student_year,student_code;

--11.List out all the departments which is having a headcount of more than 10

select * from department_master

--12.List the total cost of library inventory ( sum of prices of all books )

select sum(bookprice) as library_inventory from book_master

--13.List out category wise count of books costing more than Rs 1000 /-

select book_category,bookprice ,count(*) as total from book_master
group by book_category,bookprice having bookprice > 1000;

--14.How many students have joined in Physics dept (dept code is 10) last year?

select s.dept_code,s.student_code from student_master s left join student d
on(s.student_code=d.student_code)
where s.dept_code=10 and datename(year,d.student_joining)=(datename(year,getdate())-1)
order by s.student_code;

select * from student_master
insert into student values(218,'joy',10,getdate(),'pune','2017-11-04')

select datename(year,getdate())-1