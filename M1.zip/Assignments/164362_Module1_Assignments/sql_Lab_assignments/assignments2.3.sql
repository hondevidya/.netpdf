--Author name: Vidya Honde
--Creation date: 15-11-18

--1. Create a Filtered Index HumanResources.Employee table present in the
--AdventureWorks database for the column EmployeeID. The index should cover all
--the queries that uses EmployeeID for its search & that select only rows with
--�Marketing Manager� for Title column.

use AdeventureWorks;

select * from HumanResources.Employee;

create clustered index employeeIndex on HumanResources.Employee(EmployeeID) 
where title='Marketing Manager';