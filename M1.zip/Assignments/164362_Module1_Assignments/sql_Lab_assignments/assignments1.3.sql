--Author name: Vidya Honde
--Creation date: 12-11-18


use Training_24Oct18_Pune

--1. User defined data type
create Type Region from varchar(15);

--2.create default which store 'NA'
create default northAmerica as 'NA';

--3.bind default to alias
exec sp_bindefault northAmerica, Region; 

--4.alter table Customer
alter table Customer add Customer_Region Region;

sp_help Customer

--5.alter table Customer add Gender col.
alter table Customer add Gendor char(1);

--6. using alter add constraint to Gender col.
alter table Customer add constraint 
ck_gendor check(Gendor in ('M','F','T'));

--7.create table Order
create table Orders
(
OrdersID int not null identity (1000, 10),
Customerid int not null, 
OrdersDate Datetime,
Order_State char(1) check(Order_State in('P','C'))
)

--8. add referential integrity constraint

select * from Customer
exec sp_help Customer
--steps
--1.remove column
alter table Customer drop column customerid

--2.add column
alter table Customer add customerid int

--delete data
truncate table customer

--4.insert into table
insert into  Customer(customerid,CustomerName,Address1,
Address2,contactnumber,PostalCode,Gendor) 
values(101,'J','s','U','1','3','M')

--4.insert into table
insert into  Customer values('K','m','t','3','2','Asia','F',102)

--3.alter primary key
alter table Customer add constraint pk_customer primary key(customerid)

--5.alter foreign key
alter table Orders add constraint 
fk_CustOrders foreign key(Customerid) 
references Customer(customerid)

--alter column not null
alter table customer alter column customerid int not null

--6.check foreign key assigned or not
exec sp_help Orders


--demo of view
alter view v1 with encryption as select * from Orders

exec sp_helptext v1



