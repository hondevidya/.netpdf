--Author name: Vidya Honde
--Creation date: 13-11-18



use Training_24Oct18_Pune;
--1.Write a query which displays Staff Name, Department Code, Department Name, 
--and Salary for all staff who earns more than 20000.



--To check tables in current databases.
exec sp_tables

select * from staff_Master;
select * from Department_master;

select s.staff_name, s.dept_code, d.Dept_name, s.salary
from Staff_Master s inner join Department_Master d
on(s.Dept_Code= d.Dept_code) where s.salary> 20000; 

--2.Write a query to display Staff Name, Department Code, and 
--Department Name for all staff who do not work in Department code 10

select s.staff_name, s.dept_code, d.Dept_name, s.salary
from Staff_Master s inner join Department_Master d
on(s.Dept_Code= d.Dept_code) where d.dept_code <>10;

--3.print book name and no of times issed.
select * from Book_Master;
select * from Book_Transaction

select bm.Book_name, count(*) as no_of_times_issed
from Book_Master bm inner join Book_Transaction bt
on (bm.book_code = bt.book_code)
group by  bm.Book_name;

--4.List out number of students joined each department last year.
use Training;

select * from dbo.Department_master;
select * from dbo.student_master;

select COUNT(*) as No_of_students
from dbo.Department_master dm inner join dbo.student_master sm
on(dm.Dept_code=sm.Dept_Code)
where sm.doj = (datename(year,getdate())-1);

select datename(year,getdate())-1;

--5.List out a report like this Staff Code Staff Name Manager Code Manager Name

select * from staff_master;

select sm1.staff_code, sm1.staff_name,sm2.mgr_code,sm2.mgr_name
from staff_master sm1 join staff_master sm2
on(sm1.staff_code=sm2.mgr_code);

--6.Display the Staff Name, Hire date and day of the week on which staff was hired.
--Label the column as DAY. Order the result by the day of the week starting with Monday.
select staff_name, hire_date, datename(dw,hire_date) as Day 
from staff_master order by Day;

--7.Display Staff Code, Staff Name, and Department 
--Name for those who have taken more than one book.
select staff_code,staff_name, dm.dept_name from department_master dm inner join(
select sm1.staff_code,sm1.staff_name, sm1.dept_code from staff_master sm1 inner join
(
select bt.book_code,bt.staff_code,count(*) as total
from staff_master sm1 inner join Book_Transaction bt  
on(sm1.staff_code=bt.staff_code)
group by bt.book_code, bt.staff_code having count(*) > 1
)as new_table 
on(new_table.staff_code=sm1.staff_code)) as result
on(result.dept_code=dm.dept_code);

select * from Department_Master
select * from staff_master
select * from Book_Transaction

--8.List out the names of all student code whose score in subject1 is equal to the highest score

select * from student
select * from student_marks

insert into student values(1003,'Joy',4,getdate(),'pune'),
(1008,'Riya',3,getdate()-10,'Parbhani'),
(1009,'Jems',1,getdate()-4,'Manwath')

select student_name from student s inner join
(
select student_code from student_marks
where (Subject1 > Subject2 and Subject1> Subject3) 
) as result_table
on(result_table.student_code=s.student_code);

--9.Modify the above query to display student names along with the codes.

select student_name, s.student_code from student s inner join
(
select student_code from student_marks
where (Subject1 > Subject2 and Subject1> Subject3) 
) as result_table
on(result_table.student_code=s.student_code);

--10.Display the Student Code, Student Name, and Department Name for that department
--in which maximum number of student are studying.

select * from Department_master
select * from student_master


select dp1.dept_name
from Department_master dp1 join
(
select sp.student_code, sp.student_name, inner_table.dept_code
from student_master sp join
(
	Select Top(1) dept_code from  student_master
    Group By dept_code
    order by Count(dept_code) desc
)as inner_table on(inner_table.dept_code=sp.Dept_Code)
) as new_one
on(new_one.dept_code=dp1.dept_code)


--11. List out the code and names of all staff and students belonging to department 20.
 
select staff_code, staff_name from staff_master where dept_code=20
union
select student_code, student_name from student_master 
where dept_code=20
union
select * from department 
where Department_ID=20

select * from staff_master

--12.List out all the students who have not appeared 
--for exams this year
select * from student_marks 
where student_year<> datename(year,getdate());

--13.List out all the student codes who have never taken books
select student_code from book_transaction
where book_issue_date is null

--14.--Add the following records to the Customers Table , created in our earlier exercises
select * from customer_164362
exec sp_help customer_164362

alter table customer_164362 add customername varchar(100)

alter table customer_164362 add gender char(1)

insert into customer_164362(customerid,customerName,address1,address2,contactnumber,postalcode) values
('ALFKI','AlfredsFutterkiste','Obere Str. 57','Berlin,Germany','030-0074321','12209'),
('ANATR','AnaTrujilloEmparedadosyhelados','Avda.de la Constituci�n 2222','M�xico D.F.,Mexico','030-0074321','5021'),
('ANTON','Antonio Moreno Taquer�a','Mataderos 2312','M�xico D.F.,Mexico','(5)555-3932','5023'),
('AROUT','Around the Horn','120 Hanover Sq.','London,UK','171555-7788','WA11DP'),
('BERGS','Berglundssnabbk�p','Berguvsv�gen 8','Lule�,Sweden','0921-1234 65','S-95822'),
('BLAUS','Blauer See Delikatessen','Forsterstr. 57','Mannheim,Germany','0621-08460','68306'),
('BLONP','Blondesddslp�re et fils','24, placeKl�ber','Strasbourg,France','88.60.15.31','67000'),
('BOLID','B�lidoComidaspre paradas','C/Araquil, 67','Madrid,Spain','(91)5552282','28023'),
('BONAP','Bon app','12, rue des Bouchers','Marseille,France','91.24.45.40','13008'),
('BOTTM','Bottom-Dollar Markets','23 Tsawassen Blvd.','Tsawassen,Canada','604-555-4729','T2F8M4')

--15.Replace the contact number of Customer id ANATR to (604) 3332345.
update customer_164362 set contactnumber='(604)3332345' 
where customerid='ANATR'

--16.Update the Address and Region of Customer BOTTM to the following
--19/2 12th Block, Spring Fields.
--Ireland - UK
--Region - EU

update customer_164362
 set address1='19/2 12th Block, Spring',
 address2='Ireland - UK',
 region='EU'
 where customerid='BOTTM'

 --16.Insert the following records in the Orders table. The Order id should be automatically generated
 use Training_24oct18_pune
 select * from orders
 exec sp_help orders



 create sequence s1 start with 1 increment by 1
 insert into orders values(next value for s1,'AROUT',datefromparts(96,'Jul',4),'P')





 --18. Delete all the Customers whose Orders have been cleared.

--19. Remove all the records from the table using the truncate command. Rerun the script
--to populate the records once again

--20. Change the order status to C, for all orders before `15th July.

