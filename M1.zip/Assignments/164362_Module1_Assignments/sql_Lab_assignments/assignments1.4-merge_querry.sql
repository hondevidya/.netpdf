--Author name: Vidya Honde
--Creation date: 13-11-18


use Training;

--1.Merger querry 
--source table.
CREATE TABLE Products
(
ProductID INT PRIMARY KEY,
ProductName VARCHAR(100),
Rate MONEY
)

select * from Products;

--Targate table
CREATE TABLE UpdatedProducts
(
ProductID INT PRIMARY KEY,
ProductName VARCHAR(100),
Rate MONEY
)

select * from UpdatedProducts;

--Synchronize the target table with
--refreshed data from source table
--When records are matched, update

MERGE Products AS TARGET
USING UpdatedProducts AS SOURCE
ON (TARGET.ProductID = SOURCE.ProductID)
WHEN MATCHED AND TARGET.ProductName <> SOURCE.ProductName
OR TARGET.Rate <> SOURCE.Rate THEN
UPDATE SET TARGET.ProductName = SOURCE.ProductName,
TARGET.Rate = SOURCE.Rate
WHEN NOT MATCHED BY TARGET THEN
INSERT (ProductID, ProductName, Rate)
VALUES (SOURCE.ProductID, SOURCE.ProductName, SOURCE.Rate)
WHEN NOT MATCHED BY SOURCE THEN
DELETE
OUTPUT $action,
DELETED.ProductID AS TargetProductID,
DELETED.ProductName AS TargetProductName,
DELETED.Rate AS TargetRate,
INSERTED.ProductID AS SourceProductID,
INSERTED.ProductName AS SourceProductName,
INSERTED.Rate AS SourceRate;
SELECT @@ROWCOUNT;
--When no records are matched, insert
--the incoming records from source
--table to target table



--2.Employee target table

CREATE TABLE EmployeeTarget
(
EmpID INT NOT NULL,
Designation VARCHAR (25) NOT NULL,
Phone VARCHAR (20) NOT NULL,
Address VARCHAR (50) NOT NULL,
CONSTRAINT PK_EmployeeTG
PRIMARY KEY (EmpID)
)

select * from EmployeeTarget;

--Source Table

CREATE TABLE EmployeeSource
(
EmpID INT NOT NULL,
Designation VARCHAR (25) NOTNULL,
Phone VARCHAR (20) NOT NULL,
Address VARCHAR (50) NOT NULL,
CONSTRAINT PK_EmployeeSC
PRIMARY KEY (EmpID)
)

select * from EmployeeSource;


--merge querry


insert into EmployeeTarget values
(102,'Full stack developer', 12334, 'ajhgdsj'),
(103,'Python Developer', 21334, 'jalna'),
(104,'Java Developer', 32334, 'aurangabad');

select * from EmployeeTarget;

insert into EmployeeSource values
(106,'C Developer', 24134, 'Pune'),
(107,' .Net developer', 878334, 'Udaypur'),
(108,'Software Developer', 894334, 'jalna'),
(109,'QA', 897334, 'aurangabad'),
(110,'DevOps', 675334, 'Parbhani');

select * from EmployeeSource;

--merge querry for updating and deleting

MERGE EmployeeTarget AS TARGET
USING EmployeeSource AS SOURCE
ON (TARGET.empid = SOURCE.empid)
WHEN MATCHED AND 
	TARGET.designation <> SOURCE.designation
	OR TARGET.phone <> SOURCE.phone THEN
UPDATE SET 
 TARGET.designation = SOURCE.designation,
 TARGET.phone = SOURCE.phone,
 TARGET.address = SOURCE.address
WHEN NOT MATCHED BY TARGET THEN
	INSERT (empid, designation, phone, address)
	VALUES (SOURCE.empid, SOURCE.designation, SOURCE.phone, SOURCE.address)
WHEN NOT MATCHED BY SOURCE THEN
DELETE
OUTPUT $action,
DELETED.empid AS TargetEmpID,
DELETED.designation AS TargetEmpDesgination,
DELETED.phone AS TargetEmpPhone,
DELETED.address AS TargetEmpAddress,
INSERTED.empid AS SourceEmpID,
INSERTED.designation AS SourceEmpDesgination,
INSERTED.phone AS SourceEmpPhone,
INSERTED.address AS SourceEmpAddress;
SELECT @@ROWCOUNT;


