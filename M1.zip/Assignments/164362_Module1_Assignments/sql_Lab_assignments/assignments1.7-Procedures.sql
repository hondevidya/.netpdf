--Author name: Vidya Honde
--Creation date: 14-11-18


use Training_24oct18_pune

--1.Write a procedure that accept Staff_Code and updates the salary and store the old
--salary details in Staff_Master_Back (Staff_Master_Back has the same structure
--without any constraint) table. The procedure should return the updated salary as the
--return value Exp< 2 then no Update Exp>= 2 and <= 5 then 20% of salary Exp> 5 then 25% of salary

create procedure staff_procedure164362 @exp int
as
begin
	if(@exp <2)
	begin
		print 'No update'
	end

	if(@exp >= 2 or @exp <= 5)
	begin
		update employee set salary=(select Salary from staff_master where (Employee_Name=staff_code));
		update staff_master set Salary=(Salary*0.2) where (@exp >= 2 or @exp <= 5);
	end

	else
	begin
		update employee set salary=(select Salary from staff_master where (Employee_Name=staff_code));
		update staff_master set Salary=(Salary*0.25) where (@exp >= 2 or @exp <= 5);
	end
end

exec staff_procedure164362 4

--disable column store index
ALTER INDEX empcolumnindex ON Employees DISABLE;

--update employee table
ALTER INDEX empcolumnindex on employees REBUILD; 

select * from employee
select * from staff_master

select * from sys.indexes where type_desc='nonclustered columnstore'

--2.Write a procedure to insert details into Book_Transaction table. Procedure should
--accept the book code and staff/student code. Date of issue is current date and the
--expected return date should be 10 days from the current date. If the expected return
--date falls on Saturday or Sunday, then it should be the next working day. Suitable
--exceptions should be handled.

create procedure book_transcation_procedure2 @bk_code int, @std_code int, @stf_code int, @result varchar(10) out
as
begin
	begin try	
		print'try start';
		insert into book_transaction(book_code,stud_code,staff_code,Issue_date,Exp_Return_date)
		values(@bk_code,@std_code,@stf_code,getdate(),(datename(dw,GETDATE())+10));
		set @result =(select IIf((datename(dw,exp_return_date)='saturday' or datename(dw,exp_return_date)='sunday'),'TRUE', 'FALSE') from book_transaction
		where  IIf((datename(dw,exp_return_date)='saturday' or datename(dw,exp_return_date)='sunday'),'TRUE', 'FALSE')='TRUE');
		print 'try end';
		if(@result='TRUE')
		begin
			update book_transaction set exp_return_date=datename(dw,GETDATE())+11;
			--where (datename(dw,exp_return_date)='saturday' or datename(dw,exp_return_date)='sunday');
		end
	end try
	begin catch
		if(@std_code is null)
			print('student code is not available');
			DECLARE @ErrorNumber INT = ERROR_NUMBER();
			DECLARE @ErrorLine INT = ERROR_LINE();
			DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
			DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
			DECLARE @ErrorState INT = ERROR_STATE();
			PRINT 'Actual error message: ' + CAST(@ErrorMessage AS VARCHAR(10));
			PRINT 'Actual error number: ' + CAST(@ErrorNumber AS VARCHAR(10));
			PRINT 'Actual line number: ' + CAST(@ErrorLine AS VARCHAR(10));		
	end catch
end

--to drop a procedure
drop procedure book_transcation_procedure2

--to execute a procedure
declare @x varchar(10)
exec book_transcation_procedure2 11, 1012, 100001, @result=@x out

select * from Book_transaction 

select * from staff_master 
select * from student_master

--3.Modify question 1 and display the results by specifying With result sets

create procedure book_transcation_procedure @bk_code int, @std_code int, @stf_code int, @result varchar(10) out
as
begin
	select staff_code, Salary, staff_name from staff_master;
	begin try	
		insert into book_transaction(book_code,stud_code,staff_code,Issue_date,Exp_Return_date)
		values(@bk_code,@std_code,@stf_code,getdate(),(datename(dw,GETDATE())+10));

		set @result = ( select IIf( (datename(dw,exp_return_date)='saturday' or datename(dw,exp_return_date)='sunday'), 'TRUE', 'FALSE')
		 as a from book_transaction bt
		 where bt.a='TRUE');

		if(@result='TRUE')
		begin
			update book_transaction set exp_return_date=datename(dw,GETDATE())+11;
			--where (datename(dw,exp_return_date)='saturday' or datename(dw,exp_return_date)='sunday');
		end
	end try
	begin catch
		if(@std_code is null)
			print('student code is not available');

			DECLARE @ErrorNumber INT = ERROR_NUMBER();
			DECLARE @ErrorLine INT = ERROR_LINE();
			DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
			DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
			DECLARE @ErrorState INT = ERROR_STATE();

			PRINT 'Actual error message: ' + CAST(@ErrorMessage AS VARCHAR(10));
			PRINT 'Actual error number: ' + CAST(@ErrorNumber AS VARCHAR(10));
			PRINT 'Actual line number: ' + CAST(@ErrorLine AS VARCHAR(10));
 
			RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);		
	end catch
end

--exec procedure
exec staff_procedure164362 1
with result sets
(
	staff_code int not null,
	salary int	
)

--4.Create a procedure that accepts the book code as parameter from the user. Display
--the details of the students/staff that have borrowed that book and has not returned
--the same. The following details should be displayed
--Student/StaffCode Student/StaffName IssueDate Designation
--ExpectedRet_Date

create procedure book_detail_dis @book_code int
as
begin
	select * from staff_master sm full join book_transaction bt on(sm.staff_code=bt.staff_code) 
	where ((bt.actual_return_date is null) and bt.book_code=@book_code)
end

exec book_detail_dis 100001

select * from Book_transaction 
select * from staff_master 
select * from student_master

--5.Write a procedure to update the marks details in the Student_marks table. The
--following is the logic.
--� The procedure should accept student code , and marks as input parameter
--� Year should be the current year.
--� Student code cannot be null, but marks can be null.
--� Student code should exist in the student master.
--� The entering record should be unique ,i.e. no previous record should exist
--� Suitable exceptions should be raised and procedure should return -1.
--� IF the data is correct, it should be added in the Student marks table and a
--success value of 0 should be returned.

select * from student_marks

exec sp_help student_marks

alter table student_marks add total_Marks int  
--alter table student_marks alter column stud_code not null 
alter table student_marks add constraint pk_stud_code primary key(stud_code)

create procedure update_stud_marks @std_code int not null, @sub1 int, @sub2 int, @sub3 int
as
begin
	begin try

		if(@std_code=stud_code)
		begin
			update student_marks set
			subject1=@sub1,
			subject2=@sub2,
			subject3=@sub3,
			total_Marks=(@sub1+@sub2+@sub3) 
			where stud_year=datename(year,getdate())
			return 0;
		end
	end try

	begin catch
		print'student_code is not valid'
		return -1;
	end catch
end

exec update_stud_marks 1001,57,78,90


--Working with throw statement
--Task 1 � Raising and Catching an Exception
USE Training;
BEGIN TRY
	INSERT dbo.TestRethrow(ID) VALUES(1);
-- Force error 2627, Violation of PRIMARY KEY constraint to be raised.
	INSERT dbo.TestRethrow(ID) VALUES(1);
END TRY
BEGIN CATCH
	PRINT 'In catch block.';
END CATCH;

--Task 3 � Using Throw to Raise an Exception Again in a Catch Block

BEGIN TRY
	INSERT dbo.TestRethrow(ID) VALUES(1);
	-- Force error 2627, Violation of PRIMARY KEY constraint to be raised.
	INSERT dbo.TestRethrow(ID) VALUES(1);
END TRY
BEGIN CATCH
	PRINT 'In catch block.';
	THROW;
END CATCH;