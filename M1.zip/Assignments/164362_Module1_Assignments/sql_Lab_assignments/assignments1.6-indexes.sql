--Author name: Vidya Honde
--Creation date: 11-11-18

use Training_24Oct18_Pune

select * from department_master
sp_help department_master
--1.Create a Unique index on Department Name for Department master Table.
create unique index dept_index on Department_master(dept_name)

--2.Try inserting the following values and observe the output
insert into Department_master values(30099.00,'Home Science'),
(400.00,'Home Science'),(100,'Home Science'),
(200,'Home Science')

--3.Create a non-clustered index for Book_Trans table on the following columns
--Boo_code, Staff_name, student name, date of issue. Try adding some values.
--Do you experience any difficulties?

select * from Book_Transaction where Book_code=10

create index book_index on Book_Transaction(Book_code,staff_code,issue_date)

insert into book_transaction values(1,32,12,getdate(),getdate(),getdate()+4,null)

--4.List the indexes created in the previous questions, from the sysindexes table.
select * from sysindexes
where id in(select object_id from sys.objects where name='department')
select object_id('dept_index')

--5.Create a View with the name StaffDetails_view with the following column name
--Staff Code, Staff Name, Department Name, Desig Name salary

use Training_24oct18_pune

create view StaffDt_view as 
(select st.Staff_code, st.staff_name,st.salary,d.dept_name from staff_master st 
inner join Department_master d on(st.dept_code=d.dept_code))

--Author name: Vidya Honde
--Creation date: 14-11-18



select * from staff_master
select * from Department_master

select * from StaffDt_view

--6.Try inserting some records in the view; Are you able to add records? Why not? Write
--your answers here.
insert into StaffDt_view values(123,'abc',4500,'IT')
--Ans:View or function 'StaffDt_view' is not updatable because the modification affects multiple base tables.

--7.Working with Filtered Index � The following Filtered Index created on
--Production.BillOfMaterials table, cover queries that return the columns defined in
--The index and that select only rows with a non-NULL value for EndDate.

USE Adventure_Work

CREATE NONCLUSTERED INDEX FIBillOfMaterialsWithEndDate
ON Production.BillOfMaterials (ComponentID, StartDate)
WHERE EndDate IS NOT NULL;

--8.View the definition of the view using the following syntax.
exec Sp_helptext StaffDt_view

--9.Using the view , List out all the staffs who have joined in the month of June

select * from StaffDt_view sv inner join staff_master st 
on(sv.staff_code=sv.staff_code)
where datename(month,st.Hiredate)='june'

--10.Create a non-clustered column store index on EmployeeID of Employees table
create nonclustered columnstore index emp_col_store_index on Employee(Employee_number)

select * from employee