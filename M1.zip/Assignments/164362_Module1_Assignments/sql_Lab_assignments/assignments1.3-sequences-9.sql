--Author name: Vidya Honde
--Creation date: 12-11-18


--Create sequences and use it.
--Task 1:
--1)
USE Training; 

--create sequence IdSequence
CREATE SEQUENCE IdSequence_164362 
AS INT START WITH 10000 INCREMENT BY 1;

--2) refresh sequence and see it in Databases | Training | Programmability | Sequences

--Task 2 � Using the Sequence to Insert New Rows

INSERT INTO Employees (Employee_code, Employee_Name)
VALUES (NEXT VALUE FOR IdSequence_164362, 'Shashank'); 

INSERT INTO Contractors (ContractorId, Name) 
VALUES (NEXT VALUE FOR IdSequence_164362, 'Vidya'); 

SELECT * FROM Employees;

SELECT * FROM Contractors;
