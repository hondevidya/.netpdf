--Author name: Vidya Honde
--Creation date: 12-11-18

--1.all databases in ur system
select * from sys.databases

--know current tables present in database.
select * from sys.tables where object_id=object_id('TestRethrow_164362')

--2.change active database
use master

--3.know current active database name
select DB_Name()

--4.change active database
use Training
use Northwind

--5.know detail info about table employee
exec sp_help 'Employee'

--6.change active database
use master

--get details of table spt_fallback_db
exec sp_help 'spt_fallback_db'


--7.get current version
select @@version

--8.get current date
select GETDATE()

--9. 
use Northwind
select * from sys.tables
exec sp_help 'products'
exec sp_help 'Orders'
exec sp_help 'Order Details'
exec sp_help 'Employees'


--10.Make a note of all related tables and foreign key columns
exec sp_fkeys 'orders'

--check relative tables
select schema_name(tab.schema_id) + '.' + tab.name as [table],
    col.column_id,
    col.name as column_name,
    case when fk.object_id is not null then '>-' else null end as rel,
    schema_name(pk_tab.schema_id) + '.' + pk_tab.name as primary_table,
    pk_col.name as pk_column_name,
    fk_cols.constraint_column_id as no,
    fk.name as fk_constraint_name
from sys.tables tab
    inner join sys.columns col 
        on col.object_id = tab.object_id
    left outer join sys.foreign_key_columns fk_cols
        on fk_cols.parent_object_id = tab.object_id
        and fk_cols.parent_column_id = col.column_id
    left outer join sys.foreign_keys fk
        on fk.object_id = fk_cols.constraint_object_id
    left outer join sys.tables pk_tab
        on pk_tab.object_id = fk_cols.referenced_object_id
    left outer join sys.columns pk_col
        on pk_col.column_id = fk_cols.referenced_column_id
        and pk_col.object_id = fk_cols.referenced_object_id
order by schema_name(tab.schema_id) + '.' + tab.name,
    col.column_id

--11.Repeat the above operation of Training database tables as well
use Training
select * from sys.tables
exec sp_help 'products'
exec sp_help 'Orders'
exec sp_help 'Order Details'
exec sp_help 'Employees'

--1.3 
create table Customer_164362
(
Customerid varchar(7) Unique NOT NULL,
CustomerName varchar(20) Not Null,
Address1 varchar(30),
Address2 varchar(30),
ContactNumber varchar(12)  Not Null,
PostalCode varchar(10)
)

--2.

CREATE TABLE Employees_164362
(
EmployeeId INT NOT NULL PRIMARY KEY,
Name NVARCHAR(255) NULL
);

--3.
CREATE TABLE Contractors_164362
(
ContractorId INT NOT NULL PRIMARY KEY,
Name NVARCHAR(255) NULL
);

--4.
USE Training;
CREATE TABLE dbo.TestRethrow_164362
(
ID INT PRIMARY KEY
);

