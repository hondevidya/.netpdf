--Author name: Vidya Honde
--Creation date: 13-11-18


use Training;

--1. create Employee Table
CREATE TABLE Employee
(
Employee_Number INT NOT NULL PRIMARY KEY,
Employee_Name VARCHAR(30) NULL,
Salary FLOAT NULL,
Department_Number INT NULL,
Region VARCHAR(30) NULL
)


select * from Employee

insert into Employee values
(1,'Joy', 30000, 1, 'NA'),
(2,'Vidya',45000,2,'H')

select * from Employee
SELECT Region, Department_Number,AVG (Salary) Average_Salary From Employee
Group BY GROUPING SETS
( (Region, Department_Number),
(Region),
(Department_Number)
)