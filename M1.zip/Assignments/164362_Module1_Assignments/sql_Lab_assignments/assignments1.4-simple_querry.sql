--Author name: Vidya Honde
--Creation date: 13-11-18


--1.4 simple querry and merge querry.

use Training;

select Student_Code, Student_Name, Department_Code from University.student

--2.for staff
select staff_Code, staff_Name, Department_Code from University.staff

--3.Retrieve the details (Name, Salary and dept code) of the employees who are working in department 20, 30 and 40.
select Employee_Name, Salary, Department_Code
from Employees where Department_Code in(20,30,40);

select * from Employees;

--4.Display Student_Code, Subjects and Total_Marks for every student. 
--Total_Marks will calculate as Subject1 + Subject2 + Subject3 from Student_Marks. 
--The records should be displayed in the descending order of Total Score

select * from Student_Marks;

select Student_Code, subject1, subject2, subject3, Subject1+Subject2+Subject3 as Total_Marks
from Student_Marks 
order by Total_Marks desc;

--5.List out all the books which starts with �An�, along with price

select book_name , BookPrice from Book_Master where book_name like 'an%';

select * from Book_Master;

--6.List out all the department codes in which students have joined this year
select department_code from Student

--7.Display name and date of birth of students where date of
-- birth must be displayed in the format similar to �January, 12 1981� 
--for those who were born on Saturday or Sunday.
select * from student

select student_name, datename(Month, student_dob)+','
+FORMAT(student_dob, 'dd yyyy') 
as date_of_birth from student
where (datename(dw,student_dob)='Saturday' 
or datename(dw,student_dob)='sunday')

--8.List out a report like this
--StaffCode StaffName Dept Code Date of Joining No of years in the Company
select Staff_Code,Staff_Name, department_code,
DateofJoining, NoOfYearinCompany from staff

--9.List out all staffs who have joined before Jan 2000
select * from staff where dateofjoining < 'Jan 2000'

--10.Write a query which will display Student_Name, 
--Departmnet_Code and DOB of all students
-- who born between January 1, 1981 and March 31, 1983.

select student_name, department_code, student_dob
from student where student_dob between 'january 1 1981' and 'March 31, 1983';

select * from student

--11.List out all student codes who did not appear in the exam subject2
select student_code from student_marks where subject2 is null;
select * from student_marks;





